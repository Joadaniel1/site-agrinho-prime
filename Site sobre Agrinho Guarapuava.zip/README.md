
  # Site sobre Agrinho Guarapuava

  This is a code bundle for Site sobre Agrinho Guarapuava. The original project is available at https://www.figma.com/design/Cle9K0mB0ggHWs1R3BJoks/Site-sobre-Agrinho-Guarapuava.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  